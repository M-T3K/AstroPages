self.assetsManifest = {
  "version": "NqJQvjao",
  "assets": [
    {
      "hash": "sha256-3ly137hZlJiqj1SaVL1eyU87NWYhnyjt9Ospm/VMG7w=",
      "url": "AstroCalculator.styles.css"
    },
    {
      "hash": "sha256-U/kUSU2FRqtwd/5YUyVUJcMiBij8huD+CbdTVR00mNU=",
      "url": "_framework/AstroCalculator.j43eu139i8.wasm"
    },
    {
      "hash": "sha256-0odpWWEsu1W2VxGsRp3N61v4AlK9rfF8sNXtEz3YdQo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.yro7n2ks67.wasm"
    },
    {
      "hash": "sha256-clEflWhed/5bQ1kuiKRVcHoB6zlyLRgYI050IQKqq/A=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.el74qat3gm.wasm"
    },
    {
      "hash": "sha256-pu76rHZnWXnD8OJbsfHeWNtvNYwvUMrsao8y79n+GXY=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.mhi741p0i5.wasm"
    },
    {
      "hash": "sha256-BXLlLHChNmKdO9DI5w9RViMSR0sg/IXOG6gHaxPoygQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.bsknd2p7nx.wasm"
    },
    {
      "hash": "sha256-AyL87FvJMf14Dcn8HeQ3n2veg/RQGVGCjfpJPt1RQC4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.f9jq6u05xu.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-0iZA+rfvr3lLmK5V18g0LZCU41c3mbTL9jNYRoavdB0=",
      "url": "_framework/Microsoft.Extensions.Configuration.ell6o7ap7i.wasm"
    },
    {
      "hash": "sha256-xJGsdCHz8ZnqW4DMzEAjFDJG+hPSdDKvwcYEdt/HJTE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.greu41qkcj.wasm"
    },
    {
      "hash": "sha256-EPey4pvx6aL8aj8zL05ip1ZJSUG7DjjOrtL9aPRDYPw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g8opmrm9gr.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-aBnl8I+SD3x3zXLX77veOrltsNcMuWifnNlGFaahme0=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.8cnp7o9mjf.wasm"
    },
    {
      "hash": "sha256-tXQZqZqNvPMoYp2INR4AOHcvE8kWly2WAYbjvmmuiXU=",
      "url": "_framework/Microsoft.Extensions.Options.9zsgy7ya5a.wasm"
    },
    {
      "hash": "sha256-iOXJ6xMILdIdSWDD2fNHtnrXI0YtuWx4chp/bwgCVgc=",
      "url": "_framework/Microsoft.Extensions.Primitives.8omryeirak.wasm"
    },
    {
      "hash": "sha256-lNqP2ot1f2PhPr/5ZgFueuYFhUgz/pVAaqmi0u4H8Lo=",
      "url": "_framework/Microsoft.JSInterop.426305nhc4.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-nmhUPBjB8ZbEN0U5j2acgnW4fkbSYlov7U3e30Lsp8A=",
      "url": "_framework/System.6bp5k9v1ih.wasm"
    },
    {
      "hash": "sha256-IRDWv/HMQJHh3Xg+M2gpYfSn6TjfE2rqOVs8bmLuP1Q=",
      "url": "_framework/System.Collections.3zvwein3nc.wasm"
    },
    {
      "hash": "sha256-cvXTuACzttrmyCtLe+4sLw/Ku5IhbIwtZLx/iZuVooo=",
      "url": "_framework/System.Collections.Concurrent.yj46ybcunl.wasm"
    },
    {
      "hash": "sha256-lUYuFae586w6RYH0u1Ae58zscwolrEH2Y4odrg1crwg=",
      "url": "_framework/System.Collections.Immutable.dy03z3jci8.wasm"
    },
    {
      "hash": "sha256-pNWrDePWfKodlJjxBCpA0AeYDZNBM9z6ukop8vIGGgI=",
      "url": "_framework/System.Collections.NonGeneric.whuhpq856d.wasm"
    },
    {
      "hash": "sha256-9qH6vIwHO1zQCCUlOCGwPjgt25T2+hZw2PITcSaQ0GU=",
      "url": "_framework/System.Collections.Specialized.imqlgxzi1z.wasm"
    },
    {
      "hash": "sha256-m5DwTBNRz+O8ALbqJYC8FO3cxMPHj6e13jHHDLufyCA=",
      "url": "_framework/System.ComponentModel.Annotations.t2sxflcb2p.wasm"
    },
    {
      "hash": "sha256-dT6xR+uLACidMz1b8LWC/E0YyGljl/0g88Z28icj5hU=",
      "url": "_framework/System.ComponentModel.Primitives.nhp6j20zz6.wasm"
    },
    {
      "hash": "sha256-9IAMPvqAES7fVTCW9SMWHun9q9fNwlIbDiPZYvaG0rE=",
      "url": "_framework/System.ComponentModel.TypeConverter.4m33yawe2x.wasm"
    },
    {
      "hash": "sha256-RYR/h0Ie5rYHB+ej3Knxr+cFNDRJ6It4r6HxoCWHpB4=",
      "url": "_framework/System.ComponentModel.xhkm7nd2fe.wasm"
    },
    {
      "hash": "sha256-xf8N4wb3OmF9s5LbMTvSzi5FfAtaTmburnd73he5WVI=",
      "url": "_framework/System.Console.15d9h9yj9z.wasm"
    },
    {
      "hash": "sha256-JA6sPl6GA5NH8pNdn7k4E0ophulug+EchR9kvweDkS0=",
      "url": "_framework/System.IO.Pipelines.g5ih8ovpg3.wasm"
    },
    {
      "hash": "sha256-dnpzUjJ6syqBUovqKTCcYpF8JCO6OwDPzz/uDn2C3VU=",
      "url": "_framework/System.Linq.Expressions.26ndfklhvw.wasm"
    },
    {
      "hash": "sha256-HxsD6yUPmwTxaarygTqwHJ/OdeVB20kxLhDi9wpnIZ4=",
      "url": "_framework/System.Linq.xchofaacn2.wasm"
    },
    {
      "hash": "sha256-IDSAjVKpw1y1xMh8awdngwnk/Z2zdrU8f7bGYksp1k4=",
      "url": "_framework/System.Memory.0023jbmx4z.wasm"
    },
    {
      "hash": "sha256-PuONLjVT+RdY6SF7OiLiUWRgrDDy0Yhg/3WsHIKKNh0=",
      "url": "_framework/System.Net.Http.if1wca2g7s.wasm"
    },
    {
      "hash": "sha256-S21BwAjdSlZYujl9gymU48gTnFdfUyHO8N4chrKPCN0=",
      "url": "_framework/System.Net.Primitives.rcgya37loz.wasm"
    },
    {
      "hash": "sha256-bxcR7iK24VlqIfqFVcU8D/3EOJ0FE1MGvS5IJOO/X6s=",
      "url": "_framework/System.ObjectModel.zzealesrsq.wasm"
    },
    {
      "hash": "sha256-pQFMt1S37djvxiP9a2BY02hh2DNS19v8gdhYymPvYxM=",
      "url": "_framework/System.Private.CoreLib.r04g600vx9.wasm"
    },
    {
      "hash": "sha256-pJQiYT9gelS5TnIje9w/iOUM38hjzVdsIgt+swnsZ3I=",
      "url": "_framework/System.Private.Uri.4i9l8wc47q.wasm"
    },
    {
      "hash": "sha256-VS4CSyZJNRAj+SrJqgbXBFWlGMlNDgM4rbwJ6gTH5qg=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.x50649m5t2.wasm"
    },
    {
      "hash": "sha256-AaR+9vhZodMQ+BvtO7cx3/+RHDXvr5BNiR6QLrCCMkQ=",
      "url": "_framework/System.Runtime.Serialization.Primitives.h4a7pnkft5.wasm"
    },
    {
      "hash": "sha256-Tty4J3229lfbmd8siVtgUsREX6A2Rp5eDxP+pJTKR6c=",
      "url": "_framework/System.Runtime.ys69l5vl3s.wasm"
    },
    {
      "hash": "sha256-3Bkwa9mSjO7xOdlVLl0/qnjjZiS82EjQaxuCRyCUaC0=",
      "url": "_framework/System.Text.Encodings.Web.wp0aonjvxd.wasm"
    },
    {
      "hash": "sha256-WR2ZY1+A6vF4FVPH/V0G0yIF6Uj6wOXYTqYSJVJSV8o=",
      "url": "_framework/System.Text.Json.9054zq8krk.wasm"
    },
    {
      "hash": "sha256-XKqW+TrmS4TjaNifmwb+yfc9w2BWkr3dUjq0xmJYmEw=",
      "url": "_framework/System.Text.RegularExpressions.gl65p7jdfx.wasm"
    },
    {
      "hash": "sha256-GUz97QkSMDSN3HM0mxclAXNwWkXRh0PgWF5Mneqpv1Y=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-GbKWK+esqeL1E24rCVsCvsQCzaJM65aknWOT1UhUYa4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-d7UNSArplVrX3arY2Kmhxp1wN79ng8hLqIBrkiQ9Gbo=",
      "url": "_framework/dotnet.native.hmanx9razn.js"
    },
    {
      "hash": "sha256-+eNtxSEiakcWrx6VoLGcDvqDWS3/kWe0AtiYmQFwe7E=",
      "url": "_framework/dotnet.native.p4lwlf2bu1.wasm"
    },
    {
      "hash": "sha256-uD1t4tsPtmIHsx30SC4OztehGGaHVDksFD38rL2e3P4=",
      "url": "_framework/dotnet.runtime.o8gq1i8bk6.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-vGbjgqEqv4y3q5OB8W2R9LthkuF8mQfHFeNdKSReSmU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-9OeMK2MVm0kpulNVtQQtSsmyAORnAOh/mN91PIUbAo0=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-WbwtDdbrvhonY6fRjUqhUFABZpPH8jB89eVAlhEwpVw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-PpE+jR5INDCs7jJk7c92XgCIdmwZFE1gZGH6fFFE4SA=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-+VA0LGelZGrViJL1+SNeyfla8oPU+TkT1If50OJI+hc=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-Rr6V8NRRqbj6VOBnjdJe9nlyR4IBOQleTHQNAMG8bBY=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-c4rhekpSuV8gSRVy+DRjtQuXpUd/lXux8Fj49PG2UMk=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-y14qhOfQg498CdAewJDZ/qrPswQkzHehE38h1Qdoie0=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-bDtT00NqgpCOH81HlpxhDq7elNnjMmDC5+dJACNblBw=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-xy/kSHe6Vj/OjanMq1G2YEcgRebNKrWxz5LjvKMD3DA=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-s+d+KFxJWsc8YcSovMqo1ROoQvdNr0k/CQzHN6yDhN0=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-fLYATe5suDQkS8YdcVQeM6YauBJXOjW9NhMg94Qhrao=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
